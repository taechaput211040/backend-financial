import { ApiProperty } from "@nestjs/swagger";
import { Expose } from "class-transformer";
import { Column, CreateDateColumn, Entity, Index, PrimaryGeneratedColumn, Unique, UpdateDateColumn } from "typeorm";

@Entity()
export class Member {
    constructor(
        partial?: Partial<Member | Member[]>
    ) {
        Object.assign(this, partial);
    }

    @PrimaryGeneratedColumn('uuid')
    @Expose() // npm i --save class-validator class-transformer
    @Index()
    id: number;
    @CreateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)" })
    public created_at: Date;

    @UpdateDateColumn({ type: "timestamp", default: () => "CURRENT_TIMESTAMP(6)", onUpdate: "CURRENT_TIMESTAMP(6)" })
    public updated_at: Date;
    @Column()
    @Expose()
    name: string;
    @Column()
    @Expose()
    lastname: string;
    @Column({ nullable: true })
    @Expose()
    nameEng: string;
    @Column({ nullable: true })
    @Expose()
    lastnameEng: string;
    @Column()
    @Expose()
    bankName: string;
    @Column()
    @Expose()
    bankAcc: string;
    @Column()
    @Expose()
    bankAccRef: string;
    @Column()
    @Expose()
    phone: string;
    @Column({ nullable: true })
    @Expose()
    lineID: string;
    @Column({ nullable: true })
    @Expose()
    recommender: string;
    @Column({ nullable: true })
    @Expose()
    knowFrom: string;
    @Column({ nullable: true })
    @Expose()
    remark: string;
    @Column({ nullable: true })
    @Expose()
    birthdate: Date;
    @Column({ nullable: true, default: false })
    @Expose()
    gender: boolean;
    @Column({ default: 0 })
    @Expose()
    bonusid: number;
    @Column({ default: true })
    @Expose()
    dpAuto: boolean;
    @Column({ default: true })
    @Expose()
    wdAuto: boolean;
    @Column()
    @Expose()
    @Index()
    username: string;
    @Column()
    password: string;
    @Column()
    @Expose()
    lastest_dpref: string;
    @Column({ nullable: true })
    @Expose()
    lastest_wdref: string;
    @Column({ nullable: true, default: 0 })
    @Expose()
    dp_count: number;
    @Column({ nullable: true, default: 0 })
    @Expose()
    wd_count: number;
    @Column({ nullable: true, default: 1 })
    @Expose()
    verified: boolean;
    @Column()
    @Expose()
    operator: string;
    @Column({ nullable: true, default: 1 })
    @Expose()
    status: boolean;
    @Column({ nullable: true })
    @Expose({name:'member_uuid'})
    @Index({unique:true})
    member_uuid_smart: string;
    //extra column
    @Column({ nullable: true })
    @Expose()
    member_id_rico: number;
    @Column({ nullable: true })
    @Expose()
    @Index()
    parent_id: string;

    @Column({ nullable: true })
    @Expose()
    @Index()
    hash:string;
    @Column({ nullable: true })
    @Expose()
    company:string;
    @Column({ nullable: true })
    @Expose()
    agent_username:string;


}
// Companybank: "KBANK"
// Companybankacountnumber: "0771244149"
// Companybankname: "ระวีวรรณ หอมทวนลม"
// balance: 4262
// balanceupdatetime: "2021-01-29 20:35:00"
// id: 6
// loginname: null
// password: ""
// status: true
// type: false
// visibletomember: true