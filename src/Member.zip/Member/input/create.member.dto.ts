import { ApiProperty } from "@nestjs/swagger";
import { IsBoolean, IsDate, IsNotEmpty, IsNumber, IsOptional, IsString, Length } from "class-validator";

export class CreateMemberDto{


   
    // npm i --save class-validator class-transformer
 
 
    
    @IsString()
    @Length(1,255)
    name:string;
    
    @IsString()
    @Length(1,255)
    lastname:string;
    
    @IsString()
    @IsOptional()
    @Length(1,255)
    nameEng:string;
    
    @IsString()
    @IsOptional()
    @Length(1,255)
    lastnameEng:string;
    @IsString()
    @Length(1,255)
    bankName:string;
    
    @IsString()
    @Length(10,15)
    bankAcc:string;
    
    @IsString()
    @Length(1,10)
    bankAccRef:string;
    
    @IsString()
    @Length(1,10)
    phone:string;
    
    @IsString()
    @IsOptional()
    @Length(1,255)
    lineID:string;
    
    @IsString()
    @IsOptional()
    @Length(1,255)
    recommender:string;
    
    @IsString()
    @IsOptional()
    @Length(1,255)
    knowFrom:string; 
    
    @IsString()
    @IsOptional()
    @Length(1,255)
    remark:string;
    
    @IsDate()
    @IsOptional()
    birthdate:Date;
  
    @IsBoolean()
    @IsOptional()
    gender:boolean;
  
    @IsNumber()
    bonusid:number;

    @IsBoolean()
    @IsOptional()
    dpAuto:boolean;

    @IsBoolean()
    @IsOptional()
    wdAuto:boolean;
    
    @IsString()
    username:string;
    @IsString()
    @Length(5,20)
    password:string;
    
    @IsString()
    @IsOptional()
    
    lastest_dpref:string;
    
    @IsString()
    @IsOptional()
    lastest_wdref:string;
    
    @IsNumber()
    @IsOptional()
    dp_count:number;
    
    @IsNumber()
    @IsOptional()
    wd_count:number;
  
    @IsBoolean()
    @IsOptional()
    verified:boolean;
    
     
    @IsString()
    @IsOptional()
    operator:string;
  
    @IsBoolean()
    @IsOptional()
    status:boolean;
    
    
    @IsString()
    @IsOptional()
    member_uuid:string;


    //extra
    @IsString()
    @IsOptional()
    parent_id: string;

    @IsString()
    hash:string;
    @IsString()
    company:string;
    @IsString()
    agent_username:string;
} 