import { BadRequestException, Body, CACHE_MANAGER, ClassSerializerInterceptor, Controller, Delete, Get, HttpCode, HttpException, HttpStatus, Inject, Logger, NotFoundException, Param, Patch, Post, Query, SerializeOptions, UseInterceptors, UsePipes, ValidationPipe } from "@nestjs/common";
import { ApiBody, ApiOkResponse, ApiParam, ApiProduces, ApiQuery, ApiResponse, ApiTags } from "@nestjs/swagger";
import { Cache } from "cache-manager";
import { CreateMemberDto } from "./input/create.member.dto";

import { MemberService } from "./member.service";


@Controller('api/Member')
@SerializeOptions({ strategy: 'excludeAll' })
@ApiTags('Rico CRUD')
export class MemberController {
    private readonly logger = new Logger(MemberController.name);
    constructor(
        @Inject(CACHE_MANAGER) private cacheManager: Cache,

        private readonly memberService: MemberService
        // private readonly transectionService: TransectionService,
    ) { }

    @Get('/:hash/:data')
    async findOne(
        @Param('hash') hash:string,
        @Param('data') data:string
    ) {

        return hash;
        // this.logger.log('getBankByHash hit');
        // const value = await this.cacheManager.get('get_all_bank' + hash);

        // if (value) {
        //     console.log(this.cacheManager)
        //     // console.log('fromchach')
        //     this.logger.log('cache getBankByHash return');
        //     return plainToClass(CompanyBank, value);
        // }

        // const bank = await this.companyBankService.getBankByHash(hash);


        // if (bank.length == 0) {
        //     this.logger.debug(`NOT Found`);
        //     throw new NotFoundException('ไม่พบข้อมูล');
        // }
        // await this.cacheManager.set('get_all_bank' + hash, bank, { ttl: null });
        // // console.log('notcache')
        // this.logger.debug(`Founded ${bank.length} records`);
        // return bank;

    }
    @Get('/Reset')
    @HttpCode(404)
    async clearcache() {
        this.logger.log('cache clear  hit');
        await this.cacheManager.reset();
        this.logger.log('cache cleared  ');
    }
    // @Get(':id')
    // @ApiParam({ name: 'id', type: 'uuid', description: 'uuid ของ ธนาคารที่ต้องการ', example: '002847c8-c34f-4ada-9218-f925557ef589' })
    // @ApiResponse({ status: 200, description: 'ได้เป็น object' })
    // @ApiResponse({ status: 404, description: 'ไม่พบข้อมูล' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async findOne(@Param('id') id) {
    //     // console.log(typeof id)
    //     this.logger.log('getBankById hit');
    //     const value = await this.cacheManager.get('get_one_bank' + id);

    //     if (value) {
    //         this.logger.log('cache getBankById return');
    //         return plainToClass(CompanyBank, value);
    //     }

    //     const bank = await this.companyBankService.getBankById(id);

    //     if (!bank) {
    //         this.logger.debug(`NOT founded`);
    //         throw new NotFoundException();
    //     }

    //     await this.cacheManager.set('get_one_bank' + id, bank, { ttl: null });
    //     this.logger.debug(`Founded`);
    //     return bank;

    // }
    // @Get('/Wd/:id')
    // @ApiParam({ name: 'id', type: 'uuid', description: 'uuid ของ ธนาคารที่ต้องการ', example: '002847c8-c34f-4ada-9218-f925557ef589' })
    // @ApiResponse({ status: 200, description: 'ได้เป็น object' })
    // @ApiResponse({ status: 404, description: 'ไม่พบข้อมูล' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async findOneWithPassword(@Param('id') id) {
    //     // console.log(typeof id)
    //     this.logger.log('findOneWithPassword hit');
    //     const value = await this.cacheManager.get('get_one_bank' + id);

    //     if (value) {
    //         this.logger.log('cache findOneWithPassword return');
    //         return value;
    //     }

    //     const bank = await this.companyBankService.getBankById(id);

    //     if (!bank) {
    //         this.logger.debug(`NOT founded`);
    //         throw new NotFoundException();
    //     }

    //     await this.cacheManager.set('findOneWithPassword' + id, {
    //         loginname: bank.loginname,
    //         password: bank.password
    //     }, { ttl: null });
    //     this.logger.debug(`Founded`);
    //     return {
    //         loginname: bank.loginname,
    //         password: bank.password
    //     };

    // }

    // @Get('/ref/:ref/:hash')
    // @ApiParam({ name: 'ref', type: 'string', description: 'string ของ ธนาคารที่ต้องการ', example: '002847c8-c34f-4ada-9218-f925557ef589' })
    // @ApiResponse({ status: 200, description: 'ได้เป็น object' })
    // @ApiResponse({ status: 404, description: 'ไม่พบข้อมูล' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async findOneByRef(
    //     @Param('ref') ref,
    //     @Param('hash') hash,
    // ) {
    //     this.logger.log('findOneByRef hit');
    //     const value = await this.cacheManager.get('get_one_bank_by_ref' + ref);

    //     if (value) {
    //         this.logger.log('cache findOneByRef return');
    //         return plainToClass(CompanyBank, value);
    //     }

    //     const bank = await this.companyBankService.getBankByRef(ref, hash);

    //     if (!bank) {
    //         this.logger.debug(`NOT founded`);
    //         throw new NotFoundException();
    //     }

    //     await this.cacheManager.set('get_one_bank_by_ref' + ref, bank, { ttl: null });
    //     this.logger.debug(`Founded`);
    //     return bank;
    // }


    // @Get('/DpBank/:hash')
    // @ApiQuery({ name: 'hash', description: 'hash', example: '32d074031b4177e7c548da97f3e0463b' })
    // @ApiResponse({ status: 200, description: 'ได้เป็น array of object' })
    // @ApiResponse({ status: 404, description: 'ไม่พบข้อมูล' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async findDp(
    //     @Param('hash') hash,
    // ) {
    //     this.logger.log('findDp hit');
    //     const value = await this.cacheManager.get('findDp' + hash);

    //     if (value) {
    //         console.log(this.cacheManager)
    //         // console.log('fromchach')
    //         this.logger.log('cache findDp return');
    //         return plainToClass(CompanyBank, value);
    //     }

    //     const bank = await this.companyBankService.getBankByHashWithDpBank(hash);


    //     if (bank.length == 0) {
    //         this.logger.debug(`NOT Found`);
    //         throw new NotFoundException('ไม่พบข้อมูล');
    //     }
    //     await this.cacheManager.set('findDp' + hash, bank, { ttl: null });
    //     // console.log('notcache')
    //     this.logger.debug(`Founded ${bank.length} records`);
    //     return bank;
    // }
    // @Get('/WdFirtst/:hash')
    // @ApiQuery({ name: 'hash', description: 'hash', example: '32d074031b4177e7c548da97f3e0463b' })
    // @ApiResponse({ status: 200, description: 'ได้เป็น array of object' })
    // @ApiResponse({ status: 404, description: 'ไม่พบข้อมูล' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async findWdFirst(
    //     @Param('hash') hash,
    // ) {
    //     this.logger.log('findWdFirst hit');
    //     const value = await this.cacheManager.get('findWdFirst' + hash);

    //     if (value) {
    //         // console.log('fromchach')
    //         this.logger.log('cache findWdFirst return');
    //         return value;
    //     }

    //     const bank = await this.companyBankService.getBankByIdWdFirst(hash);


    //     if (!bank) {
    //         this.logger.debug(`NOT founded`);
    //         throw new NotFoundException();
    //     }
    //     await this.cacheManager.set('findWdFirst' + hash, {
    //         companyBank: bank.Companybank,
    //         loginname: bank.loginname,
    //         password: bank.password
    //     }, { ttl: null });
    //     // console.log('notcache')
    //     this.logger.debug(`Founded `);
    //     return {
    //         companyBank: bank.Companybank,
    //         loginname: bank.loginname,
    //         password: bank.password
    //     };
    // }


    // @Get('/Check/:bankAcc')
    // @ApiQuery({ name: 'bankAcc', description: 'hash', example: '32d074031b4177e7c548da97f3e0463b' })
    // @ApiResponse({ status: 200, description: 'ได้เป็น array of object' })
    // @ApiResponse({ status: 404, description: 'ไม่พบข้อมูล' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async findBankAccExist(
    //     @Param('bankAcc') bankAcc,
    // ) {
    //     this.logger.log('findBankAccExist hit');
    //     // const value = await this.cacheManager.get('findBankAccExist' + bankAcc);

    //     // if (value) {
    //     //     console.log(this.cacheManager)
    //     //     // console.log('fromchach')
    //     //     this.logger.log('cache findBankAccExist return');
    //     //     return plainToClass(CompanyBank, value);
    //     // }
     
       
    //     let exists = await this.companyBankService.checkBankAccExist(bankAcc);
    //     const a = 1;
       
    //     if (exists) {
    //         this.logger.debug(`founded 1 `);
    //         return { result: true };
    //     } else {
    //         this.logger.debug(`not found `);
    //         return { result: false };
    //     }
    //     // await this.cacheManager.set('findBankAccExist' + bankAcc, exists, { ttl: null });
    //     // console.log('notcache')

    //     return exists
    // }

    @Post('/:hash')
    @UsePipes(new ValidationPipe({ transform: true }))
   

    @UseInterceptors(ClassSerializerInterceptor)
    async createMember(
        @Param('hash') hash:string,
        @Body() input: CreateMemberDto,
       

    ) {
      
        
        this.logger.log('createMember hit');
        const result = await this.memberService.dataValidate(
            input,hash
        ).catch(err => {
            this.logger.log(`createBank error occuroccur ${err.message}`);
            if (err.message.includes('ER_DUP_ENTRY')) {
                this.logger.log('createBank error DUPLICATE account number');
                throw new HttpException({
                    message: 'เลขบัญชีธนาคารซ้ำกับในระบบ'
                }, HttpStatus.INTERNAL_SERVER_ERROR);
            } else {
                this.logger.log(`createBank error occur ${err.message}`);
                throw new HttpException({
                    message: err.message
                }, HttpStatus.BAD_REQUEST);
            }
        });
        this.logger.log('createBank success');

        let transection = new Transection();

        transection.operation = "create company bank";
        transection.operator = input.createBy + ' ' + input.companyName + ' ' + input.agentPrefixCode;
        transection.payload = JSON.stringify(input)
        await this.transectionService.saveTransection(transection)
        await this.cacheManager.reset();
        this.logger.log('Cache cleared');
        return result;
    }
    // @Patch(':id')
    // @UsePipes(new ValidationPipe({ transform: true }))
    // @HttpCode(202)
    // @ApiParam({ name: 'id', type: 'uuid', description: 'uuid ของ ธนาคารที่ต้องการแก้ไขข้อมูล', example: '002847c8-c34f-4ada-9218-f925557ef589' })
    // @ApiBody({ type: [UpdateCompanyBankDto], description: 'ทุก field เป็น optional ไม่จำเป็นต้องส่งมาทั้งหมด ยกเว้น updateBy ต้องใส่มาทุกครั้ง ' })
    // @ApiResponse({ status: 202, description: 'ได้ object ที่อัพเดทสำเร็จ กลับมา' })
    // @ApiResponse({ status: 404, description: 'ไม่เจอ uuid ร้องขอ' })
    // @UseInterceptors(ClassSerializerInterceptor)
    // async update(@Param('id') id, @Body() input: UpdateCompanyBankDto) {
    //     this.logger.log('update hit');
    //     if (!input.updateBy) {
    //         this.logger.log('no updateBy Bye!');
    //         throw new BadRequestException('กรุณะระบุผู้ทำรายการ');
    //     }
    //     this.logger.log('getBankById hit');
    //     const bank = await this.companyBankService.getBankById(id);

    //     if (!bank) {
    //         this.logger.debug(`NOT founded`);
    //         throw new NotFoundException();
    //     }
    //     this.logger.debug(`founded`);
    //     await this.cacheManager.reset();
    //     this.logger.debug(`cache cleared`);

    //     const udres = await this.companyBankService.updateBank(bank, input);
    //     this.logger.debug(`${bank.id} is updated`);

    //     let transection = new Transection();

    //     transection.operation = "update company bank";
    //     transection.operator = input.updateBy + ' ' + bank.companyName + ' ' + bank.agentPrefixCode;
    //     transection.payload = JSON.stringify(input)
    //     await this.transectionService.saveTransection(transection)
    //     return udres
    // }
    // @Delete(':id')
    // @HttpCode(204)
    // @ApiParam({
    //     name: 'id',
    //     required: true,
    //     description: 'ใส่ UUID ที่ต้องการจะลบ นะครับ',
    // }
    // )
    // @ApiBody({ description: 'ใส่ updateBy มาด้วยทุกครั้ง ' })
    // @ApiResponse({ status: 204, description: 'ลบสำเร็จ' })
    // @ApiResponse({ status: 400, description: 'ไม่มีผู้กระทำการ' })
    // @ApiResponse({ status: 404, description: 'ไม่เจอ uuid ร้องขอ' })
    // async remove(@Param('id') id, @Body() input: UpdateCompanyBankDto) {
    //     this.logger.log('Delete hit');
    //     if (!input.updateBy) {
    //         this.logger.log('no updateBy Bye!');
    //         throw new BadRequestException('กรุณะระบุผู้ทำรายการ');
    //     }
    //     const bank = await this.companyBankService.getBankById(id);



    //     if (!bank) {
    //         this.logger.log('Not found record');
    //         throw new NotFoundException();
    //     }

    //     await this.cacheManager.reset();
    //     this.logger.log(`Cache of ${id} is cleared`);
    //     await this.companyBankService.deleteBank(id);
    //     this.logger.debug(`${id} is deleted`);
    //     let transection = new Transection();

    //     transection.operation = "delete company bank";
    //     transection.operator = input.updateBy + ' ' + bank.companyName + ' ' + bank.agentPrefixCode;
    //     transection.payload = JSON.stringify(bank)
    //     await this.transectionService.saveTransection(transection)

    // }

}