import { BadRequestException, HttpService, Injectable, Logger } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { DeleteResult, Repository, SelectQueryBuilder } from "typeorm";
import { CreateMemberDto } from "./input/create.member.dto";
import { Member } from "./member.entity";

@Injectable()
export class MemberService {
    private readonly logger = new Logger(MemberService.name)
    constructor(
        private httpService: HttpService,
        @InjectRepository(Member)
        private readonly companyBanksRepository: Repository<Member>
    ) {

    }
    private getMemberBaseQuery(): SelectQueryBuilder<Member> {
        return this.companyBanksRepository
            .createQueryBuilder('m')
            .orderBy('b.id', 'DESC')

    }
    private getMemberBaseQueryByHash(hash:string): SelectQueryBuilder<Member> {
        return this.getMemberBaseQuery()
           .andWhere('b.hash = :hash', { hash })

    }
    private async countByphone(phone: string, hash: string): Promise<Number> {
        const query = this.getMemberBaseQueryByHash(hash)
            .andWhere('b.phone = :phone', { phone })
        return await query.getCount()

    }
    private async countByBankAcc(bankAcc: string, hash: string): Promise<Number> {
        const query = this.getMemberBaseQueryByHash(hash)
            .andWhere('b.bankAcc = :bankAcc', { bankAcc })
        return await query.getCount()

    }
    private async countByNameAndLastname(name: string,lastname:string, hash: string): Promise<Number> {
        const query = this.getMemberBaseQueryByHash(hash)
            .andWhere('b.name = :name', { name })
            .andWhere('b.lastname = :lastname', { lastname })
        return await query.getCount()

    }
    private async companyBankCheck(bankAcc: string, hash: string): Promise<Boolean> {
        if(await this.countByBankAcc(bankAcc,hash) > 0){
            return true;
        }
        const url = process.env.ALL_COMPANY_BANK +'/api/Company/Check/'+bankAcc;

        try {
            const result = await this.httpService.get(url).toPromise();
            return result.data.result
        } catch (error) {
            return true;
            
        }
    }
    private async criminalCheck(name:string,lastname:string,phone:string,bankAcc: string, hash: string): Promise<Boolean> {
        if(await this.countByNameAndLastname(name,lastname,hash) > 0){
            return true;
        }
        const url = process.env.MAIN_CRIMINAL_SERVICE_URL +'/CheckCriminal';

        try {
            const result = await this.httpService.post(url,{
                name:name,
                lastname:lastname,
                phone:phone,
                bankaccount:bankAcc
            }).toPromise();
            return result.data.result
        } catch (error) {
            return true;
            
        }
    }
    public async dataValidate(input: CreateMemberDto, hash: string): Promise<Object | undefined> {

        if (await this.countByphone(input.phone, hash) > 0) {
            return {
                status: false,
                data: new BadRequestException('เบอร์โทรศัพท์ซ้ำกับในระบบ')
            }
        }
        if (await this.companyBankCheck(input.bankAcc, hash)) {
            return {
                status: false,
                data: new BadRequestException('เลขบัญชีซ้ำกับในระบบ')
            }
        }
        if (await this.countByNameAndLastname(input.name,input.lastname, hash) > 0) {
            return {
                status: false,
                data: new BadRequestException('ชื่อและนามสกุลซ้ำกับในระบบ')
            }
        }

            this.logger.debug(`getBankById SQL =${query.getSql()}`)
            return await query.getOne();
       
        // private getEventsBaseQueryMemberRandom(): SelectQueryBuilder<CompanyBank> {
        //     const query = this.companyBanksRepository
        //         .createQueryBuilder('b')
        //         .orderBy("RAND()")
        //         .andWhere('b.type = 0')
        //         .andWhere('b.status = 1')
        //         .andWhere('b.visibletomember = 1')
        //     // this.logger.debug(`getEventsBaseQueryMemberRandom SQL =${query.getSql()}`)
        //     return query

        // }
        // private getEventsBaseQueryMemberWithdraw(): SelectQueryBuilder<CompanyBank> {
        //     const query = this.companyBanksRepository
        //         .createQueryBuilder('b')
        //         .andWhere('b.type = 1')
        //         .andWhere('b.status = 1')
        //         .andWhere('b.visibletomember = 1')

        //     // this.logger.debug(`getEventsBaseQueryMemberWithdraw SQL =${query.getSql()}`)
        //     return query


        // }
        // private getEventsBaseQueryValidBank(): SelectQueryBuilder<CompanyBank> {
        //     const query = this.companyBanksRepository
        //         .createQueryBuilder('b')
        //         .andWhere('b.status = 1')
        //         .andWhere('b.visibletomember = 1')
        //     // this.logger.debug(`getEventsBaseQueryValidBank SQL =${query.getSql()}`)
        //     return query

        // }
        // private async generateCompanyAgentPrefixMd5(companyName: string, prefix: string) {
        //     const hash = await md5(companyName + prefix);

        //     return hash;

        // }

        // private generateBankAccRef(bankName: string, bankAcc: string, phone: string) {
        //     if (bankName == 'KBANK') { //    0911319896   X131989X
        //         bankAcc = bankAcc.substring(3, 9);
        //         let bankAccRef = 'X' + bankAcc + 'X'
        //         return bankAccRef;
        //     } else if (bankName == 'TRUEWALLET') {

        //         return phone.toString();
        //     } else if (bankName == 'GSB') {
        //         bankAcc = bankAcc.substring(6);
        //         let bankAccRef = 'X' + bankAcc;
        //         return bankAccRef;
        //     } else if (bankName == 'BAAC') {
        //         bankAcc = bankAcc.substring(6);
        //         let bankAccRef = 'X' + bankAcc;
        //         return bankAccRef;
        //     } else {//     4300867619   X867619
        //         bankAcc = bankAcc.substring(4);
        //         let bankAccRef = 'X' + bankAcc;
        //         return bankAccRef;
        //     }

        // }
        // public async getBankById(id: string): Promise<CompanyBank | undefined> {

        //     const query = this.getEventsBaseQuery()
        //         .andWhere('b.id = :id', { id })
        //     this.logger.debug(`getBankById SQL =${query.getSql()}`)
        //     return await query.getOne();
        // }
        // public async getBankByIdWdFirst(hash: string): Promise<CompanyBank | undefined> {

        //     const query = this.getEventsBaseQuery()
        //         .andWhere('b.hash = :hash', { hash })
        //         .andWhere('b.type = 1')
        //         .andWhere('b.status = 1')
        //     this.logger.debug(`getBankById SQL =${query.getSql()}`)
        //     return await query.getOne();
        // }
        // public async getBankByRef(ref: string,hash:string): Promise<CompanyBank | undefined> {

        //     const query = this.getEventsBaseQuery()
        //         .andWhere('b.bankAccRef = :ref', { ref })
        //         .andWhere('b.hash=:hash',{hash})
        //     this.logger.debug(`getBankByRef SQL =${query.getSql()}`)
        //     return await query.getOne();
        // }

        // public async checkBankAccExist(bankAcc: string): Promise<CompanyBank | undefined> {

        //     const query = this.getEventsBaseQuery()
        //     .andWhere('b.Companybankacountnumber = :bankAcc', { bankAcc })
        // this.logger.debug(`checkBankAccExist SQL =${query.getSql()}`)
        // return await query.getOne();


        // }
        // public async getBankByHash(hash: string): Promise<CompanyBank[] | undefined> {

        //     const query = this.getEventsBaseQuery()
        //         .andWhere('b.hash = :hash', { hash })

        //     this.logger.debug(`getBankByHash SQL =${query.getSql()}`)

        //     return await query.getMany();
        // }
        // public async getBankByHashWithDpBank(hash: string): Promise<CompanyBank[] | undefined> {

        //     const query = this.getEventsBaseQuery()
        //         .andWhere('b.hash = :hash', { hash })
        //         .andWhere('b.type = 0')
        //         .andWhere('b.status = 1')

        //     this.logger.debug(`getBankByHash SQL =${query.getSql()}`)

        //     return await query.getMany();
        // }
        // public async getBankByPhoneKeyMobile(phone: string, bankKey: string): Promise<CompanyBank | undefined> {

        //     const query = this.getEventsBaseQuery()

        //         .andWhere('b.phone = :phone', { phone })
        //         .andWhere('b.companyKey = :bankKey', { bankKey })
        //     this.logger.debug(`getBankByPhoneKeyMobile SQL =${query.getSql()}`)
        //     return await query.getOne();
        // }
        // public async createBank(input: CreateCompanyBankDto): Promise<CompanyBank> {
        //     const hash = await this.generateCompanyAgentPrefixMd5(input.companyName, input.agentPrefixCode)
        //     return await this.companyBanksRepository.save(
        //         new CompanyBank({
        //             ...input,
        //             hash: hash,
        //             bankAccRef: this.generateBankAccRef(input.Companybank, input.Companybankacountnumber, input.phone)

        //         })
        //     );


        // }
        // public async updateBank(bank: CompanyBank, input: UpdateCompanyBankDto): Promise<CompanyBank> {

        //     if (input.phone) {
        //         if (input.Companybank ? input.Companybank : bank.Companybank == 'TRUEWALLET') {
        //             input.bankAccRef = input.phone
        //         }
        //     }
        //     if (input.Companybank == 'TRUEWALLET') {
        //         input.bankAccRef = input.phone ? input.phone : bank.phone;
        //         input.Companybankacountnumber = input.phone ? input.phone : bank.phone;
        //     }
        //     if (input.Companybankacountnumber) {
        //         input.bankAccRef = this.generateBankAccRef(
        //             input.Companybank ? input.Companybank : bank.Companybank,
        //             input.Companybankacountnumber ? input.Companybankacountnumber : bank.Companybankacountnumber,
        //             input.phone ? input.phone : bank.phone)
        //     }
        //     return await this.companyBanksRepository.save(
        //         new CompanyBank({
        //             ...bank,
        //             ...input

        //         })
        //     );

        // }
        // public async deleteBank(id: string): Promise<DeleteResult> {

        //     const query = this.companyBanksRepository
        //         .createQueryBuilder('b')
        //         .delete()
        //         .where('id = :id', { id })

        //     this.logger.debug(`deleteBank SQL =${query.getSql()}`)
        //     return await query.execute();

        // }
        // public async getDepositeBankByMemberBank(memberBank: string, hash: string): Promise<CompanyBank | undefined> {


        //     const kbank = 'KBANK';
        //     const scb = 'SCB';
        //     const truewallet = 'TRUEWALLET';

        //     if (memberBank == 'KBANK') {
        //         const query = this.getEventsBaseQueryMemberRandom()

        //             .andWhere('b.hash = :hash', { hash })
        //             .andWhere('b.CompanyBank = :kbank', { kbank })
        //         this.logger.debug(`getDepositeBankByMemberBank KBANK SQL =${query.getSql()}`)
        //         return await query.getOne();
        //     } else if (memberBank == 'TRUEWALLET') {
        //         const query = this.getEventsBaseQueryMemberRandom()

        //             .andWhere('b.hash = :hash', { hash })
        //             .andWhere('b.CompanyBank = :truewallet', { truewallet })
        //         this.logger.debug(`getDepositeBankByMemberBank TRUEWALLET SQL =${query.getSql()}`)
        //         return await query.getOne();
        //     } else {
        //         const query = this.getEventsBaseQueryMemberRandom()

        //             .andWhere('b.hash = :hash', { hash })
        //             .andWhere('b.CompanyBank = :scb', { scb })
        //         this.logger.debug(`getDepositeBankByMemberBank SCB SQL =${query.getSql()}`)
        //         return await query.getOne();
        //     }



        // }
        // public async getDepositeBankByMemberFirst(hash: string): Promise<CompanyBank | undefined> {
        //     const bank = 'TRUEWALLET';

        //     const query = this.getEventsBaseQueryMemberRandom()
        //         .andWhere('b.hash = :hash', { hash })
        //         .andWhere('b.CompanyBank != :bank',{bank})
        //     this.logger.debug(`getDepositeBankByMemberFirst SQL =${query.getSql()}`)
        //     return await query.getOne();
        // }
        // public async getWithdrawBankByMemberBank(hash: string): Promise<CompanyBank | undefined> {
        //     const query = this.getEventsBaseQueryMemberWithdraw()
        //         .andWhere('b.hash = :hash', { hash })
        //     this.logger.debug(`getWithdrawBankByMemberBank SQL =${query.getSql()}`)
        //     return await query.getOne();
        // }
        // public async getDepositeBankDashboardByHash(hash: string): Promise<CompanyBank[] | undefined> {
        //     const query = this.getEventsBaseQuery()

        //         .andWhere('b.hash = :hash', { hash })
        //         .andWhere('b.type = 0')
        //     this.logger.debug(`getDepositeBankDashboardByHash SQL =${query.getSql()}`)
        //     return await query.getMany();
        // }
        // public async getWithdrawBankDashboardByHash(hash: string): Promise<CompanyBank[] | undefined> {
        //     const query = this.getEventsBaseQueryValidBank()
        //         .andWhere('b.hash = :hash', { hash })
        //         .andWhere('b.type = 1')
        //     this.logger.debug(`getWithdrawBankDashboardByHash SQL =${query.getSql()}`)
        //     return await query.getMany();
        // }
    }
